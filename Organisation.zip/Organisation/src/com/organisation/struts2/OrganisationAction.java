package com.organisation.struts2;

import com.organisation.dao.OrganisationDao;

public class OrganisationAction 
{

	public int organisationId;
	private String organisationName;

	
	    
	
	public int getOrganisationId() {
		return organisationId;
	}



	public void setOrganisationId(int organisationId) {
		this.organisationId = organisationId;
	}



	public String getOrganisationName() {
		return organisationName;
	}



	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}


	
	public String execute(){  
	    int i=OrganisationDao.save(this);  
	    int id=OrganisationDao.retrieve(this);  
	    if(i>0){  
	    return "success";  
	    }  
	    return "error";  
	
	}
}
