package com.organisation.struts2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException; 
import java.util.ArrayList;
import java.util.List;


public class Registers {

	static List<User> list=null;
	public static List<User> records() throws SQLException 
	{
		Connection conn=null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","gunjan");
			
			PreparedStatement ps=conn.prepareStatement("select o.OrgName,e.EmpName from organisation o INNER JOIN employee e ON o.OrgId=e.OrgId order by OrgName");
			rs=ps.executeQuery();
			//System.out.println("Hi");
			User bean=null;
			list=new ArrayList<>();
			while (rs.next()) {
				bean=new User();
				bean.setOrganisation_name(rs.getString("ORGNAME"));  
				bean.setEmployee_name(rs.getString("EMPNAME"));  
				System.out.println(rs.getString("EMPNAME"));
				list.add(bean);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			conn.close();
		}
	}
	
	}  
	
