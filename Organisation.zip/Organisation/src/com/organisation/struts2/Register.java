package com.organisation.struts2;

import com.organisation.dao.RegisterDao;

public class Register {
	private String userName;
	private String password;
	//private Login log=null;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String execute1()
	{
		int i=RegisterDao.register(this);
		if(i>0)
		{ 
			return "registersuccess";
		}
		return "registererror";
	}
}
