package com.organisation.struts2;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.dispatcher.SessionMap;
//import org.apache.struts2.dispatcher.SessionMap;
//import org.apache.struts2.interceptor.SessionAware;


import com.opensymphony.xwork2.ActionSupport;
import com.organisation.dao.LoginDao;

public class Login extends ActionSupport
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;
	private SessionMap<String, Object> sessionMap;
   public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public void setSession(Map<String, Object> map) {
		sessionMap = (SessionMap<String, Object>) map;
	}

public String execute()
   { 
	
	//HttpSession session = ServletActionContext.getRequest().getSession(true);
	HttpServletRequest req = ServletActionContext.getRequest();
	setUserName(req.getParameter("userName"));
	setPassword(req.getParameter("password"));
	
	int res=LoginDao.Validate(userName, password);
	
	if(res==1) {
		return "loginsuccess";
		} 
else {
	
	 return "loginerror";
		
	}}

public void validate()
{
	if (userName == null || userName.trim().equals("")) {
        addFieldError("name","The name is required");
     }
}
public String logout() {
	
	sessionMap.remove("userName");
	sessionMap.invalidate();
	
	return "logout";
}

}		 
	  
