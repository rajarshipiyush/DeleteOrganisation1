package com.organisation.struts2;

import com.organisation.dao.AddEmployeeDao;


public class EmployeeDetails 
{
	public int empId;
	private String firstName;
	private String lastName;
	public int temporaryId;
	public int tempId;
	public String organisation;
	
	public String execute() throws Exception {
		
		  int i=AddEmployeeDao.save(this);
		   int id=AddEmployeeDao.retrieve(this);
		   
		    if(i>0){  
		    return "success";  
		    }  
		    return "error";  
		   }
	   

	
	
	
	   public String getOrganisation() {
		return organisation;
	}



	public void setOrganisation(String organisation) {
		this.organisation = organisation;
	}



	
	   
	public int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}



	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	   
	   
	

}
