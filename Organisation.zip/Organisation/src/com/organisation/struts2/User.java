package com.organisation.struts2;

import java.util.List;


public class User {

	private String organisation_name;
	private String employee_name;
	List<User> list= null;
	
	public String getOrganisation_name() {
		return organisation_name;
	}
	public void setOrganisation_name(String organisation_name) {
		this.organisation_name = organisation_name;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

public List<User> getList() {
	return list;
}

public void setList(List<User> list) {
	this.list = list;
}

public String printRecords() throws Exception{
	
	list=Registers.records();
	
	if(list.isEmpty())
	{
		return "error";
	}
	else
	{
		return "success";
	}
}

}
