package com.organisation.struts2;


import com.organisation.dao.OrganisationDeleteDao;

public class OrganisationDelete 
{
	
	OrganisationDeleteDao dao = new OrganisationDeleteDao();
	
	public String execute() throws Exception{
		try{
			int isdeleted = dao.deleteOrg(orgName);
			if(isdeleted>0)
				return "success";
			else
				return "fail";
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return "success";
	}	
		private String orgName;
		private String orgId;
		
		public String getOrgName() {
			return orgName;
		}
		public void setOrgName(String orgName) {
			this.orgName = orgName;
		}
		public String getOrgId() {
			return orgId;
		}
		public void setOrgId(String orgId) {
			this.orgId = orgId;
		}
		
		

	}


