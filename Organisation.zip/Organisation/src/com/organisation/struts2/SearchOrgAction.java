package com.organisation.struts2;

import java.util.List;

import com.organisation.dao.SearchOrgDao;

public class SearchOrgAction {

	private int orgId;
	private String orgName;
	private int empId;
	private String empName;
	
	public int getOrgId() {
		return orgId;
	}
	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}
	
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	  List<SearchOrgAction> list= null;
	
	public String printRecords() throws Exception{
		
		list=SearchOrgDao.recordsOrg(getOrgName());
		
		if(list.isEmpty())
		{
			return "error";
		}
		else
		{
			return "success";
		}
	}
	
	public List<SearchOrgAction> getList() {
		return list;
	}

	public void setList(List<SearchOrgAction> list) {
		this.list = list;
	}
	
}
