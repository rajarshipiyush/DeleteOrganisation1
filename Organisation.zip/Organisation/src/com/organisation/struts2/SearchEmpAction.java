package com.organisation.struts2;

import java.util.List;

import com.organisation.dao.SearchOrgDao;

public class SearchEmpAction {

	private String orgName;
	private int empId;
	private String empName;
	
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	 List<SearchEmpAction> list= null;
		
		public String printRecords() throws Exception{
			
			list=SearchOrgDao.recordsEmp(getEmpName());
			//System.out.println(listEmp);
			if(list.isEmpty())
			{
				return "error";
			}
			else
			{
				return "success";
			}
		}
	
	public List<SearchEmpAction> getList() {
		return list;
	}

	public void setList(List<SearchEmpAction> list) {
		this.list = list;
	}
	
}
