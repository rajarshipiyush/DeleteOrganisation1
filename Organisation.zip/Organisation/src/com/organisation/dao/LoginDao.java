package com.organisation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;

//import com.organisation.struts2.Login;

public class LoginDao {
	


	public static  int Validate(String userName,String password)
	{
		int result=0;
				try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","gunjan");
			 PreparedStatement ps=con.prepareStatement("select username,password from login where username=? and password=?");
				   ps.setString(1, userName);
				   ps.setString(2,password);
			ResultSet resultSet = ps.executeQuery();
			resultSet.next(); 
			
				String user=resultSet.getString("userName");
				String pass=resultSet.getString("password");
				if(userName.equals(user) && password.equals(pass))
				{
					result=1;
				}
			
			else 
			{
				result=2;
			}
			
				}
		catch(Exception e)
		{
			e.printStackTrace();
			}
		return result;
			
		
	}
	
	
	
	}
