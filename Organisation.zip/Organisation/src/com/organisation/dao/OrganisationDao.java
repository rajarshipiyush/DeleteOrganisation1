package com.organisation.dao;

import java.sql.*;

import com.organisation.struts2.OrganisationAction;

public class OrganisationDao 
{

	
	public static int save(OrganisationAction r){  
		int status=0;  
		try{  
			
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","system","gunjan");  
		  
		PreparedStatement ps=con.prepareStatement("insert into organisation (orgid,orgname) values(organisation_sequence.nextval,?)");  
		
		ps.setString(1,r.getOrganisationName());  
		
		          
		status=ps.executeUpdate();  
		  
		}catch(Exception e){e.printStackTrace();}  
		    return status;  
		} 
	
	public static int retrieve(OrganisationAction r)
	{
		
		try
		{
					Class.forName("oracle.jdbc.driver.OracleDriver");  
					Connection con=DriverManager.getConnection(  
					"jdbc:oracle:thin:@localhost:1521:xe","system","gunjan");  
					PreparedStatement ps1=con.prepareStatement("SELECT ORGID FROM organisation WHERE orgname=?");
					ps1.setString(1,r.getOrganisationName());
					ResultSet rs=ps1.executeQuery();
					while (rs.next())
					{
						r.organisationId=rs.getInt("ORGID");
					}
			
					
		}
		catch (Exception e2)
		{
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		return r.organisationId;			
	}
}
