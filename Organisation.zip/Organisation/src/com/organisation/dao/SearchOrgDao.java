package com.organisation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.organisation.struts2.SearchEmpAction;
import com.organisation.struts2.SearchOrgAction;

public class SearchOrgDao {

	static List<SearchOrgAction> list=null;
	static List<SearchEmpAction> listEmp=null;
	public static List<SearchOrgAction> recordsOrg(String orgName) throws SQLException 
	{
		
		Connection conn=null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","gunjan");
			
			PreparedStatement ps=conn.prepareStatement("select o.OrgId as ORGID,o.OrgName as ORGNAME,e.Empid as EMPID,e.Empname as EMPNAME from ORGANISATION o INNER JOIN EMPLOYEE e ON o.OrgId=e.OrgId where o.OrgName=?");
			ps.setString(1,orgName);
			rs=ps.executeQuery();
			
			SearchOrgAction bean=null;
			list=new ArrayList<>();
			while (rs.next()) {
				bean=new SearchOrgAction();
				bean.setOrgId(rs.getInt("ORGID"));
				bean.setOrgName(rs.getString("ORGNAME"));
				bean.setEmpId(rs.getInt("EMPID"));
				bean.setEmpName(rs.getString("EMPNAME"));
				list.add(bean);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			conn.close();
		}
	}
	public static List<SearchEmpAction> recordsEmp(String empName) throws SQLException 
	{
		Connection conn=null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","gunjan");
			
			PreparedStatement ps=conn.prepareStatement("select o.OrgName,e.Empid,e.Empname from ORGANISATION o INNER JOIN EMPLOYEE e ON o.OrgId=e.OrgId where e.EmpName=?");
			ps.setString(1,empName);
			rs=ps.executeQuery();
			
			SearchEmpAction beanEmp=null;
			listEmp=new ArrayList<>();
			while (rs.next()) {
				beanEmp=new SearchEmpAction();
				beanEmp.setOrgName(rs.getString("ORGNAME"));
				beanEmp.setEmpId(rs.getInt("EMPID"));
				beanEmp.setEmpName(rs.getString("EMPNAME"));
				listEmp.add(beanEmp);
			}
			return listEmp;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			conn.close();
		}
	}

}
