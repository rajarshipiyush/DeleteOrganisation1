package com.organisation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

//import com.organisation.struts2.Login;
import com.organisation.struts2.Register;


public class RegisterDao {
	public static int register(Register register)
	{
	int status=1;
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","gunjan");
		PreparedStatement ps=con.prepareStatement("insert into login values(?,?)");
		ps.setString(1, register.getUserName());
		ps.setString(2,register.getPassword());
		status=ps.executeUpdate();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return status;

}}
