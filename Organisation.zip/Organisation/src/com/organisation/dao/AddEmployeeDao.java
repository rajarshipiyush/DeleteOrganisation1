package com.organisation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.organisation.struts2.EmployeeDetails;  
public class AddEmployeeDao 
{
	public static int id;
	
	
	public static int save(EmployeeDetails e){  
		int status=0;  
		try{  
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","system","gunjan");  
		  PreparedStatement ps3=con.prepareStatement("SELECT ORGID FROM ORGANISATION WHERE ORGNAME=?");
		  ps3.setString(1,e.getOrganisation());
		  ResultSet rs3=ps3.executeQuery();
		  if(rs3.next())
		  {
			 id=rs3.getInt(1);
		  }
		  
		PreparedStatement ps=con.prepareStatement("insert into EMPLOYEE values(EMP_SEQ.NEXTVAL,?,?)");
		
		ps.setString(1,e.getFirstName());
		ps.setInt(2,id);
		          
		status=ps.executeUpdate();
		
		
		  
		}catch(Exception e1){e1.printStackTrace();}  
		    return status;  
		


		// TODO Auto-generated method stub
		
	}  
	
	public static int retrieve(EmployeeDetails e)
	{
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection(  
					"jdbc:oracle:thin:@localhost:1521:xe","system","gunjan"); 
			      
			       
					PreparedStatement ps1=con1.prepareStatement("SELECT EMPID FROM EMPLOYEE WHERE EMPNAME=?");
					ps1.setString(1, e.getFirstName());
					ResultSet rs=ps1.executeQuery();
					while (rs.next())
					{
						e.empId=rs.getInt("EMPID");
					}
			
					System.out.println(e.empId);
					
		}
		catch (Exception e2)
		{
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		return e.empId;
		
		
				
	}
	

}
