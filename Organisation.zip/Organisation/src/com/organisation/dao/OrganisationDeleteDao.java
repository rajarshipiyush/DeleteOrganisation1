package com.organisation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class OrganisationDeleteDao 
{

		 public int deleteOrg(String orgName) throws SQLException, Exception {
			 //getConnection().setAutoCommit(false);
				int i = 0;
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");  
					Connection con=DriverManager.getConnection(  
					"jdbc:oracle:thin:@localhost:1521:xe","SYSTEM","gunjan");
					String sql = "delete from organisation where orgname=?";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.setString(1,orgName);
					i = ps.executeUpdate();
					return i;
				} catch (Exception e) {
					e.printStackTrace();
					//getConnection().rollback();
					return 0;
				} 
				}
			}




